package com.austin.displaydate.components;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DisplayDateComponent {
    // class definition and imports here...
    @Controller
    public class date {
        @RequestMapping("/date")
        public String dates(Model model) {
            String date = new SimpleDateFormat("EEE, dd MMM yyyy").format(new Date());
            model.addAttribute("date", date);
            return "date.jsp";
        }
    }
    @Controller
    public class Home {
        @RequestMapping("")
        public String home(Model model) {
            return "home.jsp";
        }
    }
    @Controller
    public class Time {
        @RequestMapping("/time")
        public String time(Model model) {
           String time = new SimpleDateFormat("h:mm a").format(new Date());
      
            model.addAttribute("time", time);
            return "time.jsp";
        }
    }

}
